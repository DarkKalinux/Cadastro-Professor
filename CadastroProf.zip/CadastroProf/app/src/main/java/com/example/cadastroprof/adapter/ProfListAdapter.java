package com.example.cadastroprof.adapter;

import com.example.cadastroprof.model.Prof;
import com.example.cadastroprof.R;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProfListAdapter extends RecyclerView.Adapter<ProfListAdapter.ViewHolder> {
    private List<Prof> professores;
    private Context context;

    public ProfListAdapter(Context context, List<Prof> professores) {
        this.context = context;
        this.professores = professores;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_professor, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Prof professor = professores.get(position);
        holder.tvNome.setText(professor.getNome());
        holder.tvDisciplina.setText(professor.getDisciplina());
    }

    @Override
    public int getItemCount() {
        return professores.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNome, tvDisciplina;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNome = itemView.findViewById(R.id.tv_nome);
            tvDisciplina = itemView.findViewById(R.id.tv_disciplina);
        }
    }
}

