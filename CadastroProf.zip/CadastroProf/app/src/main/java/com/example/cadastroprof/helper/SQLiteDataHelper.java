package com.example.cadastroprof.helper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteDataHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "ProfessoresDB";
    public static final int DATABASE_VERSION = 1;
    public static final String TABLE_PROFESSORES = "professores";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_MATRICULA = "matricula";
    public static final String COLUMN_NOME = "nome";
    public static final String COLUMN_DISCIPLINA = "disciplina";
    public static final String COLUMN_DATA_ADMISSAO = "data_admissao";

    private static final String CREATE_TABLE_PROFESSORES =
            "CREATE TABLE " + TABLE_PROFESSORES + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_MATRICULA + " INTEGER, " +
                    COLUMN_NOME + " TEXT, " +
                    COLUMN_DISCIPLINA + " TEXT, " +
                    COLUMN_DATA_ADMISSAO + " TEXT);";

    public SQLiteDataHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_PROFESSORES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PROFESSORES);
        onCreate(db);
    }
}


