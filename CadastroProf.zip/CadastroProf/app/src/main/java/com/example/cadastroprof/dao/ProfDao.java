package com.example.cadastroprof.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import com.example.cadastroprof.model.Prof;
import com.example.cadastroprof.helper.SQLiteDataHelper;

public class ProfDao {

    private SQLiteDataHelper dbHelper;

    public ProfDao(Context context) {
        dbHelper = new SQLiteDataHelper(context);
    }

    public boolean inserir(Prof prof) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("matricula", prof.getMatricula());
        values.put("nome", prof.getNome());
        values.put("disciplina", prof.getDisciplina());
        values.put("data_admissao", prof.getDataAdmissao());

        // Inserindo o professor no banco
        long result = db.insert("professores", null, values);

        db.close();
        return result != -1;
}
}
