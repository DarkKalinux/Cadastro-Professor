package com.example.cadastroprof.dao;

import java.util.List;

public interface IGenericDao<T> {
    long inserir(T obj);
    List<T> listar();
}



