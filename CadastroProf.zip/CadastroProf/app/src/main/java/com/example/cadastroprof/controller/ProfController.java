package com.example.cadastroprof.controller;

import android.content.Context;
import com.example.cadastroprof.dao.ProfDao;
import com.example.cadastroprof.model.Prof;

public class ProfController {

    private ProfDao profDao;

    public ProfController(Context context) {
        profDao = new ProfDao(context);
    }

    public boolean salvarProfessor(Prof prof) {

        return profDao.inserir(prof);
}
}

