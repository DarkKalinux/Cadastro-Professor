package com.example.cadastroprof.model;

public class Prof {
    private int matricula;
    private String nome;
    private String disciplina;
    private String dataAdmissao;

    // Construtor
    public Prof(int matricula, String nome, String disciplina, String dataAdmissao) {
        this.matricula = matricula;
        this.nome = nome;
        this.disciplina = disciplina;
        this.dataAdmissao = dataAdmissao;
    }

    // Getters e Setters
    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public String getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(String dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }

    // Método de validação
    public boolean validar() {
        return matricula > 0 && nome != null && !nome.isEmpty() &&
                disciplina != null && !disciplina.isEmpty() &&
                dataAdmissao != null && !dataAdmissao.isEmpty();
}
}

