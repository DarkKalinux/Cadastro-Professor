package com.example.cadastroprof.view;

import com.example.cadastroprof.R;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.cadastroprof.controller.ProfController;
import com.example.cadastroprof.model.Prof;

public class CadastroProfessorActivity extends AppCompatActivity {

    private EditText edtMatricula, edtNome, edtDisciplina, edtDataAdmissao;
    private Button btnCadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_professor);

        // Inicializando os componentes da interface
        edtMatricula = findViewById(R.id.edtMatricula);
        edtNome = findViewById(R.id.edtNome);
        edtDisciplina = findViewById(R.id.edtDisciplina);
        edtDataAdmissao = findViewById(R.id.edtDataAdmissao);
        btnCadastrar = findViewById(R.id.btnCadastrar);

        // Definindo a ação do botão de cadastro
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Captura dos dados inseridos pelo usuário
                String matriculaStr = edtMatricula.getText().toString();
                String nome = edtNome.getText().toString();
                String disciplina = edtDisciplina.getText().toString();
                String dataAdmissao = edtDataAdmissao.getText().toString();

                // Verificar se os campos estão preenchidos
                if (matriculaStr.isEmpty() || nome.isEmpty() || disciplina.isEmpty() || dataAdmissao.isEmpty()) {
                    Toast.makeText(CadastroProfessorActivity.this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    // Convertendo matrícula para inteiro
                    int matricula = Integer.parseInt(matriculaStr);

                    // Criar o objeto Prof
                    Prof professor = new Prof(matricula, nome, disciplina, dataAdmissao);

                    // Validar os dados antes de salvar
                    if (!professor.validar()) {
                        Toast.makeText(CadastroProfessorActivity.this, "Dados inválidos, verifique os campos.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Salvar o professor no banco
                    ProfController profController = new ProfController(CadastroProfessorActivity.this);
                    boolean sucesso = profController.salvarProfessor(professor);

                    // Exibir mensagem conforme o resultado
                    if (sucesso) {
                        Toast.makeText(CadastroProfessorActivity.this, "Professor cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
                        limparCampos();
                    } else {
                        Toast.makeText(CadastroProfessorActivity.this, "Erro ao cadastrar o professor. Tente novamente.", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(CadastroProfessorActivity.this, "Matrícula deve ser um número válido!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Método para limpar os campos após o cadastro
    private void limparCampos() {
        edtMatricula.setText("");
        edtNome.setText("");
        edtDisciplina.setText("");
        edtDataAdmissao.setText("");
    }
}


